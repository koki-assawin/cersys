@echo off
chcp 65001 >nul
title ติดตั้งระบบแยกไฟล์ PDF
cd /d "%~dp0"

echo ==================================================
echo    ติดตั้งระบบแยกไฟล์ PDF (ทำครั้งเดียว)
echo ==================================================
echo.

rem --- หา Python ---
set "PY="
python --version >nul 2>&1 && set "PY=python"
if not defined PY (
    py -3 --version >nul 2>&1 && set "PY=py -3"
)
if not defined PY (
    echo [X] ไม่พบ Python ในเครื่องนี้
    echo.
    echo     1. ดาวน์โหลด Python 3.10 ขึ้นไป จากหน้าเว็บที่กำลังเปิดให้
    echo     2. ตอนติดตั้ง ให้ติ๊ก "Add Python to PATH" ด้วย
    echo     3. ติดตั้งเสร็จแล้ว ดับเบิลคลิกไฟล์นี้อีกครั้ง
    echo.
    start "" https://www.python.org/downloads/
    pause
    exit /b 1
)

for /f "tokens=*" %%v in ('%PY% --version') do echo [OK] พบ %%v
echo.

rem --- สร้าง virtual environment แยกเฉพาะโปรแกรมนี้ ---
rem venv ที่คัดลอกมาจากเครื่องอื่นจะใช้ไม่ได้ ให้ลบแล้วสร้างใหม่
if exist "venv\Scripts\python.exe" (
    "venv\Scripts\python.exe" -c "import sys" >nul 2>&1 || rmdir /s /q venv
)
if not exist "venv\Scripts\python.exe" (
    echo [..] กำลังสร้างสภาพแวดล้อมของโปรแกรม...
    %PY% -m venv venv
    if errorlevel 1 (
        echo [X] สร้าง venv ไม่สำเร็จ
        pause
        exit /b 1
    )
)

echo [..] กำลังติดตั้งไลบรารี (ต้องต่ออินเทอร์เน็ต)...
"venv\Scripts\python.exe" -m pip install --upgrade pip -q
"venv\Scripts\python.exe" -m pip install -r requirements.txt -q
if errorlevel 1 (
    echo.
    echo [X] ติดตั้งไลบรารีไม่สำเร็จ กรุณาตรวจสอบอินเทอร์เน็ตแล้วลองใหม่
    pause
    exit /b 1
)

echo.
echo ==================================================
echo    [OK] ติดตั้งเสร็จเรียบร้อย
echo    ครั้งต่อไปดับเบิลคลิก "2_เปิดโปรแกรม.bat" เพื่อใช้งาน
echo ==================================================
echo.
pause
