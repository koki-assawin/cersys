"""
Flask web application for PDF Splitter.
"""

import os
import io
import zipfile
from flask import Flask, render_template, request, send_file, jsonify
from werkzeug.utils import secure_filename

from pdf_splitter import split_by_parts, split_by_size, get_pdf_info, get_split_preview

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100MB max upload

ALLOWED_EXTENSIONS = {'pdf'}


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/upload', methods=['POST'])
def upload_file():
    """Handle file upload and return PDF info."""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400

    if not allowed_file(file.filename):
        return jsonify({'error': 'Only PDF files are allowed'}), 400

    try:
        # Read file into memory to avoid Windows file locking issues
        file_bytes = file.read()
        info = get_pdf_info(io.BytesIO(file_bytes))
        return jsonify({
            'success': True,
            'filename': secure_filename(file.filename),
            'pages': info['page_count'],
            'size_mb': info['file_size_mb']
        })
    except Exception as e:
        return jsonify({'error': f'Error reading PDF: {str(e)}'}), 400


@app.route('/split', methods=['POST'])
def split_pdf():
    """Split the uploaded PDF and return a zip file."""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400

    file = request.files['file']
    split_method = request.form.get('method', 'parts')

    if not allowed_file(file.filename):
        return jsonify({'error': 'Only PDF files are allowed'}), 400

    try:
        # Read file into memory to avoid Windows file locking issues
        file_bytes = file.read()
        pdf_stream = io.BytesIO(file_bytes)
        base_name = os.path.splitext(secure_filename(file.filename))[0]

        # Get naming pattern
        naming_pattern = request.form.get('naming_pattern', 'number')
        custom_prefix = request.form.get('custom_prefix', '')
        start_number = int(request.form.get('start_number', 1))

        print(f"[DEBUG] Split method: {split_method}")
        print(f"[DEBUG] File size: {len(file_bytes)} bytes")
        print(f"[DEBUG] Naming pattern: {naming_pattern}, Start number: {start_number}")

        if split_method == 'parts':
            num_parts = int(request.form.get('num_parts', 2))
            print(f"[DEBUG] Splitting into {num_parts} parts")
            if num_parts < 1:
                return jsonify({'error': 'Number of parts must be at least 1'}), 400
            results = split_by_parts(pdf_stream, num_parts, base_name, naming_pattern, custom_prefix, start_number)
        else:
            max_size = float(request.form.get('max_size', 5))
            print(f"[DEBUG] Splitting by max size: {max_size} MB")
            if max_size <= 0:
                return jsonify({'error': 'Max size must be greater than 0'}), 400
            results = split_by_size(pdf_stream, max_size, base_name, naming_pattern, custom_prefix, start_number)

        print(f"[DEBUG] Created {len(results)} parts")
        for fname, data in results:
            print(f"[DEBUG]   - {fname}: {len(data)} bytes")

        # If only 1 part, warn user
        if len(results) == 1:
            print("[DEBUG] Warning: Only 1 part created - file may be too small to split")

        # Create zip file with all parts
        zip_buffer = io.BytesIO()
        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
            for filename, pdf_bytes in results:
                zip_file.writestr(filename, pdf_bytes)

        zip_buffer.seek(0)

        return send_file(
            zip_buffer,
            mimetype='application/zip',
            as_attachment=True,
            download_name=f'{base_name}_split.zip'
        )

    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Error processing PDF: {str(e)}'}), 500


if __name__ == '__main__':
    app.run(debug=True, port=5000)
