@echo off
chcp 65001 >nul
title ระบบแยกไฟล์ PDF - ห้ามปิดหน้าต่างนี้ระหว่างใช้งาน
cd /d "%~dp0"

"venv\Scripts\python.exe" -c "import flask, pypdf" >nul 2>&1
if errorlevel 1 (
    echo ยังไม่ได้ติดตั้งโปรแกรม กำลังเริ่มติดตั้งให้...
    echo.
    call "%~dp01_ติดตั้ง.bat"
    "venv\Scripts\python.exe" -c "import flask, pypdf" >nul 2>&1 || exit /b 1
    cls
)

echo ==================================================
echo    ระบบแยกไฟล์ PDF กำลังทำงาน
echo    เปิดเบราว์เซอร์ที่: http://localhost:5000
echo.
echo    ** ห้ามปิดหน้าต่างนี้ระหว่างใช้งาน **
echo    ใช้งานเสร็จแล้ว ปิดหน้าต่างนี้ได้เลย
echo ==================================================
echo.

rem เปิดเบราว์เซอร์หลังเซิร์ฟเวอร์เริ่มทำงาน 3 วินาที
start "" /b cmd /c "timeout /t 3 /nobreak >nul & start "" http://localhost:5000"

"venv\Scripts\python.exe" app.py

echo.
echo โปรแกรมหยุดทำงานแล้ว
pause
