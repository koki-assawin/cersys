"""
PDF Splitter Module
Provides functions to split PDFs by number of parts or max file size.
"""

import os
import io
from typing import List, Tuple
from pypdf import PdfReader, PdfWriter


def get_pdf_info(pdf_source) -> dict:
    """Get information about a PDF file.

    Args:
        pdf_source: Either a file path (str) or a BytesIO object
    """
    if isinstance(pdf_source, str):
        reader = PdfReader(pdf_source)
        file_size = os.path.getsize(pdf_source)
    else:
        # BytesIO object
        pdf_source.seek(0, 2)  # Seek to end
        file_size = pdf_source.tell()
        pdf_source.seek(0)  # Reset to beginning
        reader = PdfReader(pdf_source)

    return {
        "page_count": len(reader.pages),
        "file_size": file_size,
        "file_size_mb": round(file_size / (1024 * 1024), 2)
    }


def get_output_filename(index: int, base_name: str, naming_pattern: str, custom_prefix: str, start_number: int = 1) -> str:
    """Generate output filename based on naming pattern."""
    actual_num = start_number + index - 1
    if naming_pattern == 'number':
        return f"{actual_num}.pdf"
    elif naming_pattern == 'original_part':
        return f"{base_name}_part{actual_num}.pdf"
    elif naming_pattern == 'custom':
        return f"{custom_prefix}{actual_num}.pdf"
    else:
        return f"{actual_num}.pdf"


def split_by_parts(pdf_source, num_parts: int, base_name: str = "document",
                   naming_pattern: str = "number", custom_prefix: str = "", start_number: int = 1) -> List[Tuple[str, bytes]]:
    """
    Split a PDF into N equal parts.

    Args:
        pdf_source: Path to the source PDF file or BytesIO object
        num_parts: Number of parts to split into
        base_name: Base name for output files
        naming_pattern: 'number', 'original_part', or 'custom'
        custom_prefix: Prefix for custom naming
        start_number: Starting number for file naming

    Returns:
        List of tuples (filename, pdf_bytes)
    """
    if isinstance(pdf_source, str):
        reader = PdfReader(pdf_source)
        base_name = os.path.splitext(os.path.basename(pdf_source))[0]
    else:
        pdf_source.seek(0)
        reader = PdfReader(pdf_source)

    total_pages = len(reader.pages)

    if num_parts < 1:
        raise ValueError("Number of parts must be at least 1")
    if num_parts > total_pages:
        raise ValueError(f"Cannot split {total_pages} pages into {num_parts} parts")
    pages_per_part = total_pages // num_parts
    remainder = total_pages % num_parts

    results = []
    current_page = 0

    for part in range(num_parts):
        writer = PdfWriter()

        # Distribute remainder pages among first parts
        pages_in_this_part = pages_per_part + (1 if part < remainder else 0)

        for _ in range(pages_in_this_part):
            writer.add_page(reader.pages[current_page])
            current_page += 1

        # Write to bytes
        output = io.BytesIO()
        writer.write(output)
        output.seek(0)

        filename = get_output_filename(part + 1, base_name, naming_pattern, custom_prefix, start_number)
        results.append((filename, output.read()))

    return results


def split_by_size(pdf_source, max_size_mb: float, base_name: str = "document",
                  naming_pattern: str = "number", custom_prefix: str = "", start_number: int = 1) -> List[Tuple[str, bytes]]:
    """
    Split a PDF so each part is under the specified size limit.

    Args:
        pdf_source: Path to the source PDF file or BytesIO object
        max_size_mb: Maximum size in MB for each part
        base_name: Base name for output files
        naming_pattern: 'number', 'original_part', or 'custom'
        custom_prefix: Prefix for custom naming
        start_number: Starting number for file naming

    Returns:
        List of tuples (filename, pdf_bytes)
    """
    if isinstance(pdf_source, str):
        reader = PdfReader(pdf_source)
        base_name = os.path.splitext(os.path.basename(pdf_source))[0]
    else:
        pdf_source.seek(0)
        reader = PdfReader(pdf_source)

    total_pages = len(reader.pages)
    max_size_bytes = int(max_size_mb * 1024 * 1024)

    if max_size_mb <= 0:
        raise ValueError("Max size must be greater than 0")
    results = []
    current_page = 0
    part_num = 1

    while current_page < total_pages:
        writer = PdfWriter()

        # Add pages until size limit is reached
        while current_page < total_pages:
            writer.add_page(reader.pages[current_page])

            # Check current size
            output = io.BytesIO()
            writer.write(output)
            current_size = output.tell()

            if current_size > max_size_bytes and len(writer.pages) > 1:
                # Remove last page and break
                new_writer = PdfWriter()
                for i in range(len(writer.pages) - 1):
                    new_writer.add_page(writer.pages[i])
                writer = new_writer
                break

            current_page += 1

            # If single page exceeds limit, keep it and warn
            if current_size > max_size_bytes and len(writer.pages) == 1:
                break

        # Write final output for this part
        output = io.BytesIO()
        writer.write(output)
        output.seek(0)

        filename = get_output_filename(part_num, base_name, naming_pattern, custom_prefix, start_number)
        results.append((filename, output.read()))
        part_num += 1

    return results


def estimate_parts_by_size(pdf_path: str, max_size_mb: float) -> int:
    """Estimate how many parts a PDF will be split into by size."""
    file_size = os.path.getsize(pdf_path)
    max_size_bytes = max_size_mb * 1024 * 1024
    return max(1, int((file_size + max_size_bytes - 1) // max_size_bytes))


def get_split_preview(pdf_source, method: str, num_parts: int = 2, max_size_mb: float = 5.0) -> dict:
    """Preview how the PDF will be split without actually splitting."""
    if isinstance(pdf_source, str):
        file_size = os.path.getsize(pdf_source)
        reader = PdfReader(pdf_source)
    else:
        pdf_source.seek(0, 2)
        file_size = pdf_source.tell()
        pdf_source.seek(0)
        reader = PdfReader(pdf_source)

    total_pages = len(reader.pages)

    if method == 'parts':
        if num_parts > total_pages:
            return {
                'error': f'Cannot split {total_pages} pages into {num_parts} parts',
                'total_pages': total_pages
            }
        pages_per_part = total_pages // num_parts
        remainder = total_pages % num_parts
        parts_info = []
        current_page = 1
        for i in range(num_parts):
            pages_in_part = pages_per_part + (1 if i < remainder else 0)
            parts_info.append({
                'part': i + 1,
                'pages': f"{current_page}-{current_page + pages_in_part - 1}",
                'page_count': pages_in_part
            })
            current_page += pages_in_part
        return {
            'method': 'parts',
            'total_pages': total_pages,
            'total_parts': num_parts,
            'parts': parts_info
        }
    else:
        # Estimate by size - rough calculation
        max_size_bytes = max_size_mb * 1024 * 1024
        avg_page_size = file_size / total_pages if total_pages > 0 else file_size
        pages_per_part = max(1, int(max_size_bytes / avg_page_size)) if avg_page_size > 0 else total_pages
        estimated_parts = max(1, (total_pages + pages_per_part - 1) // pages_per_part)

        return {
            'method': 'size',
            'total_pages': total_pages,
            'file_size_mb': round(file_size / (1024 * 1024), 2),
            'max_size_mb': max_size_mb,
            'estimated_parts': estimated_parts,
            'note': 'Actual parts may vary based on page content'
        }
